// Example of App component in app.js
import React from 'react';
import LandingPage from './pages/LandingPage';


function App() {
    return (
        <div className="App">
            <LandingPage />
        </div>
    );
}

export default App;

